<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DemoTrade\\Providers\\DemoTradeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DemoTrade\\Providers\\DemoTradeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);